document.addEventListener('DOMContentLoaded', function() {
    // Populate service options
    var serviceSelect = document.getElementById('service');
    var services = ['Haircut', 'Manicure', 'Pedicure', 'Facial', 'Massage'];
    services.forEach(function(service) {
        var option = document.createElement('option');
        option.text = service;
        serviceSelect.add(option);
    });

    // Handle form submission
    var form = document.getElementById('appointment-form');
    form.addEventListener('submit', function(event) {
        event.preventDefault();
        var name = document.getElementById('name').value;
        var email = document.getElementById('email').value;
        var selectedService = serviceSelect.options[serviceSelect.selectedIndex].text;
        var date = document.getElementById('date').value;
        // Here you can send the appointment details to the server or perform other actions
        alert('Appointment booked successfully!\nName: ' + name + '\nEmail: ' + email + '\nService: ' + selectedService + '\nDate: ' + date);
        form.reset();
    });
});
